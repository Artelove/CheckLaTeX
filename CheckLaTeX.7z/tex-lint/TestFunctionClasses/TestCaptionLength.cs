﻿namespace TexLint.TestFunctionClasses;

public class TestCaptionLength
{
    public TestCaptionLength()
    {
        
    }
}