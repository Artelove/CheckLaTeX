﻿namespace TexLint.Models
{
    public enum ErrorType
    {
        Warning = 1,
        Error = 2,
        Info = 3,
        Debug = 4
    }
}