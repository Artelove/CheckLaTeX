﻿namespace TexLint.Models.HandleInfos
{
    public enum ParameterParseType
    {
        Phrase = 1,
        Value = 2
    }
}